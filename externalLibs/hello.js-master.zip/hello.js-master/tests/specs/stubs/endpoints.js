export default [
	'facebook/get/me/picture.json',
	'google/get/me/file;id.json',
	'google/get/me/files.json',
	'instagram/post/me/likes-error.json',
	'yahoo/get/default.json'
];

