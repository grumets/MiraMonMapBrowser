
1.2.0 / 2016-01-03
==================

  * NEW: Twitch icon. Thanks @inquam
  * NEW: join.me icon. Might be a bit broken. Thanks @suttonj

1.1.1 / 2015-07-04
==================

  * FIX: broken bower.json

1.1.0 / 2015-07-03
==================

  * NEW: now also distributed on NPM
  * NEW: website is now published trough the same repo (thanks @crowmagnumb !)
  * CHANGE: official instagram icon
  * FIX: general code and packaging cleanup

1.0.0 / 2015-04-11
==================

First versioned release !

Recently added fontcustom support.

