This file contains assets for the website

It does not contain any specific code or resources for the actual project