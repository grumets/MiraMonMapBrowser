# HelloJS Help and Support

If you are having problems implementing HelloJS you might find your answers already discussed. Please see...

* Issues at [Github](https://github.com/MrSwitch/hello.js/issues)
* FAQ's at [Stackoverflow](http://stackoverflow.com/questions/tagged/hello.js)

Want to discuss your implementations?

* Discussions at [Gitter](https://gitter.im/MrSwitch/hello.js)

If you are experiencing a bug in HelloJS or would like the library to support other services and features. Please [create a new issue](https://github.com/MrSwitch/hello.js/issues/new).
